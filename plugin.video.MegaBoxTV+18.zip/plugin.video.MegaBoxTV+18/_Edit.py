import xbmcaddon
MainBase = 'https://gist.githubusercontent.com/Gunboybr/5af065924debe7ccd636bfb5f81b2b58/raw/addonadulto+18'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV+18')